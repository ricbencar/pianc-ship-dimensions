package org.pianc.vesselscharacteristics

import java.nio.file.Files
import java.nio.file.Path
import java.security.MessageDigest

internal fun readMainAsset(name: String): String {
    val candidates = listOf(
        Path.of("src", "main", "assets", name),
        Path.of("app", "src", "main", "assets", name),
    )
    val path = candidates.firstOrNull { candidate -> Files.isRegularFile(candidate) }
        ?: error("Could not locate main asset '$name' from ${Path.of("").toAbsolutePath()}.")
    return Files.readString(path)
}

internal fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
    .digest(text.toByteArray(Charsets.UTF_8))
    .joinToString(separator = "") { byte -> "%02x".format(byte.toInt() and 0xff) }
