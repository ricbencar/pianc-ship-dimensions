package org.pianc.vesselscharacteristics

import org.pianc.vesselscharacteristics.calculation.VesselInterpolator
import org.pianc.vesselscharacteristics.data.CalculatedValue
import org.pianc.vesselscharacteristics.data.DataValue
import org.pianc.vesselscharacteristics.data.InputOutOfRangeException
import org.pianc.vesselscharacteristics.data.PiancDatabase
import org.pianc.vesselscharacteristics.data.PythonDatabaseParser
import org.pianc.vesselscharacteristics.data.VesselCalculation
import org.pianc.vesselscharacteristics.data.VesselColumn
import org.pianc.vesselscharacteristics.data.VesselDataset
import org.pianc.vesselscharacteristics.data.VesselTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class VesselInterpolatorParityTest {
    private val wg235: VesselDataset by lazy {
        PythonDatabaseParser(readMainAsset(PiancDatabase.WG235.assetName))
            .parse(PiancDatabase.WG235)
    }
    private val wg121: VesselDataset by lazy {
        PythonDatabaseParser(readMainAsset(PiancDatabase.WG121.assetName))
            .parse(PiancDatabase.WG121)
    }

    @Test
    fun wg235MidIntervalPchipAndNearestClassMatchPython() {
        val result = calculate(
            dataset = wg235,
            vessel = "Crude Oil & Larger Product Tankers",
            characteristic = "DWT_deadweight_tonnage (t)",
            value = 125_000.0,
        )

        assertText(result, "Class_name", "Aframax")
        assertDecimals(
            result,
            "DWT_deadweight_tonnage (t)" to 125_000.0,
            "Displacement_fully_laden (t)" to 146_815.0,
            "Cargo_capacity (t)" to 118_628.87,
            "Loa_length_overall (m)" to 255.8,
            "Lbp_length_between_perpendiculars (m)" to 244.52,
            "B_beam (m)" to 45.65,
            "T_fully_laden (m)" to 15.2,
            "Cb_block_coefficient ()" to 0.84,
            "Loa_length_overall_max (m)" to 259.96,
            "Lbp_length_between_perpendiculars_max (m)" to 253.43,
            "B_beam_max (m)" to 45.19,
            "T_fully_laden_max (m)" to 16.39,
            "Moulded_depth (m)" to 21.8,
            "Air_draft_ballast (m)" to 50.0,
            "Lateral_windage_fully_loaded (m2)" to 3_016.64,
            "Lateral_windage_in_ballast (m2)" to 5_163.25,
            "Longitudinal_windage_fully_loaded (m2)" to 989.85,
            "Longitudinal_windage_in_ballast (m2)" to 1_341.03,
        )
        assertEquals(19, result.results.size)
    }

    @Test
    fun wg235DuplicateInputRowsAreAveragedBeforeInterpolation() {
        val result = calculate(
            dataset = wg235,
            vessel = "Bulk Carriers",
            characteristic = "DWT_deadweight_tonnage (t)",
            value = 100_000.0,
        )

        assertText(result, "Class_name", "Post-Panamax (wide)")
        assertDecimals(
            result,
            "DWT_deadweight_tonnage (t)" to 100_000.0,
            "Displacement_fully_laden (t)" to 115_000.0,
            "Cargo_capacity (t)" to 95_000.0,
            "Loa_length_overall (m)" to 245.0,
            "Lbp_length_between_perpendiculars (m)" to 240.5,
            "B_beam (m)" to 40.5,
            "T_fully_laden (m)" to 13.85,
            "Cb_block_coefficient ()" to 0.83,
            "Loa_length_overall_max (m)" to 245.0,
            "Lbp_length_between_perpendiculars_max (m)" to 240.5,
            "B_beam_max (m)" to 40.5,
            "T_fully_laden_max (m)" to 14.6,
            "Moulded_depth (m)" to 19.25,
            "Air_draft_ballast (m)" to 50.0,
            "Lateral_windage_fully_loaded (m2)" to 2_450.0,
            "Lateral_windage_in_ballast (m2)" to 4_550.0,
            "Longitudinal_windage_fully_loaded (m2)" to 750.0,
            "Longitudinal_windage_in_ballast (m2)" to 1_050.0,
        )
    }

    @Test
    fun wg235PassengerCapacityUsesPythonIntegerRoundingRule() {
        val result = calculate(
            dataset = wg235,
            vessel = "Ferries",
            characteristic = "GT",
            value = 4_500.0,
        )

        // GT 4500 is exactly midway between 3000 and 6000. NumPy's default
        // unstable argsort has no contractual tie order, so the Android port
        // deliberately uses the first/lower sorted source row.
        assertText(result, "Class_name", "Medium Ro-Pax Ferry")
        assertInteger(result, "Cargo_capacity (passengers)", 990L)
        assertDecimals(
            result,
            "Displacement_fully_laden (t)" to 5_000.0,
            "Loa_length_overall (m)" to 98.67,
            "Lbp_length_between_perpendiculars (m)" to 89.68,
            "B_beam (m)" to 16.15,
            "T_fully_laden (m)" to 4.7,
            "Cb_block_coefficient ()" to 0.73,
            "Loa_length_overall_max (m)" to 113.76,
            "Lbp_length_between_perpendiculars_max (m)" to 102.9,
            "B_beam_max (m)" to 23.87,
            "T_fully_laden_max (m)" to 5.45,
            "Moulded_depth (m)" to 9.15,
            "Air_draft_ballast (m)" to 26.72,
            "Lateral_windage_fully_loaded (m2)" to 799.66,
            "Lateral_windage_in_ballast (m2)" to 926.02,
            "Longitudinal_windage_fully_loaded (m2)" to 186.41,
            "Longitudinal_windage_in_ballast (m2)" to 211.87,
        )
    }

    @Test
    fun wg235SparseOutputOutsideItsOwnSupportMatchesPythonNan() {
        val result = calculate(
            dataset = wg235,
            vessel = "Container Ships (Post-Panamax)",
            characteristic = "DWT_deadweight_tonnage (t)",
            value = 240_000.0,
        )

        assertTrue(decimal(result, "Air_draft_ballast (m)").isNaN())
        // The Python code's case-sensitive integer-column list does not match this source name.
        assertEquals(
            CalculatedValue.Decimal(24_000.0),
            result.value("Cargo_capacity (TEU)"),
        )
    }

    @Test
    fun wg121CapacityAndPchipValuesMatchPython() {
        val result = calculate(
            dataset = wg121,
            vessel = "LNG Carriers (Prismatic)",
            characteristic = "dm_maximum_mass_displacement (t)",
            value = 70_000.0,
        )

        assertInteger(result, "Capacity", 112_809L)
        assertDecimals(
            result,
            "Loa_Length_overall (m)" to 267.38,
            "Lbp_length_between_perpendiculars (m)" to 254.94,
            "B_beam (m)" to 40.33,
            "T_laden (m)" to 10.69,
            "Cb_block_coefficient ()" to 0.73,
            "dm_fully_laden (t)" to 82_726.22,
            "Lateral_windage_fully_loaded (m2)" to 5_473.99,
            "Lateral_windage_in_ballast (m2)" to 5_918.87,
        )
    }

    @Test
    fun wg121AllMissingColumnsRemainInsufficientAndAvailableColumnsInterpolate() {
        val result = calculate(
            dataset = wg121,
            vessel = "Motor Boats",
            characteristic = "Loa_Length_overall (m)",
            value = 10.5,
        )

        assertDecimals(
            result,
            "Loa_Length_overall (m)" to 10.5,
            "B_beam (m)" to 3.05,
            "T_laden (m)" to 1.65,
            "dm_fully_laden (t)" to 5.92,
        )
        listOf(
            "dm_maximum_mass_displacement (t)",
            "Lbp_length_between_perpendiculars (m)",
            "Cb_block_coefficient ()",
            "Capacity",
            "Lateral_windage_fully_loaded (m2)",
            "Lateral_windage_in_ballast (m2)",
        ).forEach { name -> assertEquals(CalculatedValue.InsufficientData, result.value(name)) }
    }

    @Test
    fun wg121DuplicateInputRowsUseTheirNumericMeans() {
        val result = calculate(
            dataset = wg121,
            vessel = "Cruise Liners (Panamax)",
            characteristic = "dm_maximum_mass_displacement (t)",
            value = 35_000.0,
        )

        assertDecimals(
            result,
            "Loa_Length_overall (m)" to 198.5,
            "Lbp_length_between_perpendiculars (m)" to 176.0,
            "B_beam (m)" to 29.15,
            "T_laden (m)" to 6.55,
            "Cb_block_coefficient ()" to 0.61,
            "dm_fully_laden (t)" to 21_000.0,
            "Lateral_windage_fully_loaded (m2)" to 5_150.0,
            "Lateral_windage_in_ballast (m2)" to 5_250.0,
        )
        assertEquals(CalculatedValue.InsufficientData, result.value("Capacity"))
    }

    @Test
    fun validRangeIsInclusiveAndNonFiniteOrOutsideValuesAreRejected() {
        val table = requireNotNull(wg235.vessel("Crude Oil & Larger Product Tankers"))
        val characteristic = "DWT_deadweight_tonnage (t)"

        assertEquals(
            CalculatedValue.Decimal(60_000.0),
            VesselInterpolator.calculate(PiancDatabase.WG235, table, characteristic, 60_000.0)
                .value(characteristic),
        )
        assertEquals(
            CalculatedValue.Decimal(450_000.0),
            VesselInterpolator.calculate(PiancDatabase.WG235, table, characteristic, 450_000.0)
                .value(characteristic),
        )
        listOf(59_999.0, 450_001.0, Double.NaN, Double.POSITIVE_INFINITY).forEach { value ->
            assertThrows(InputOutOfRangeException::class.java) {
                VesselInterpolator.calculate(PiancDatabase.WG235, table, characteristic, value)
            }
        }
    }

    @Test
    fun pythonColumnNamingRoundingAndNearestRowTieRulesArePreserved() {
        val table = VesselTable(
            name = "Synthetic",
            columns = listOf(
                numericColumn("x", 0.0, 1.0),
                numericColumn("Capacity", 2.0, 3.0),
                numericColumn("Cargo_capacity (passengers)", 3.0, 4.0),
                numericColumn("cargo_capacity_(teu)", 2.0, 3.0),
                numericColumn("Cargo_capacity (TEU)", 2.0, 3.0),
                VesselColumn(
                    name = "Class_name",
                    values = listOf(DataValue.Text("lower"), DataValue.Text("upper")),
                ),
            ),
        )

        val result = VesselInterpolator.calculate(
            database = PiancDatabase.WG235,
            table = table,
            knownCharacteristic = "x",
            knownValue = 0.5,
        )

        assertInteger(result, "Capacity", 2L)
        assertInteger(result, "Cargo_capacity (passengers)", 4L)
        assertInteger(result, "cargo_capacity_(teu)", 2L)
        assertEquals(CalculatedValue.Decimal(2.5), result.value("Cargo_capacity (TEU)"))
        assertText(result, "Class_name", "lower")
    }

    private fun calculate(
        dataset: VesselDataset,
        vessel: String,
        characteristic: String,
        value: Double,
    ): VesselCalculation = VesselInterpolator.calculate(
        database = dataset.database,
        table = requireNotNull(dataset.vessel(vessel)),
        knownCharacteristic = characteristic,
        knownValue = value,
    )

    private fun assertDecimals(
        result: VesselCalculation,
        vararg expected: Pair<String, Double>,
    ) {
        expected.forEach { (name, value) ->
            assertEquals("Unexpected value for $name", value, decimal(result, name), 0.0)
        }
    }

    private fun decimal(result: VesselCalculation, name: String): Double =
        (result.value(name) as CalculatedValue.Decimal).value

    private fun assertInteger(result: VesselCalculation, name: String, expected: Long) {
        assertEquals(CalculatedValue.Integer(expected), result.value(name))
    }

    private fun assertText(result: VesselCalculation, name: String, expected: String) {
        assertEquals(CalculatedValue.Text(expected), result.value(name))
    }

    private fun VesselCalculation.value(name: String): CalculatedValue =
        results.single { it.name == name }.value

    private fun numericColumn(name: String, vararg values: Double): VesselColumn = VesselColumn(
        name = name,
        values = values.map(DataValue::Numeric),
    )
}
