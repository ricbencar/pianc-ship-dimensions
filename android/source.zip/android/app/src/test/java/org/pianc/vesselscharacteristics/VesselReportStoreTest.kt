package org.pianc.vesselscharacteristics

import org.pianc.vesselscharacteristics.report.VesselReportStore
import java.io.File
import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Test

class VesselReportStoreTest {
    @Test
    fun replaceDiscardsPreviouslySavedReport() {
        val reportFile = Files.createTempFile("vessel-report", ".txt").toFile()

        try {
            VesselReportStore.replace(reportFile, "first calculation\n")
            VesselReportStore.replace(reportFile, "latest calculation\n")

            assertEquals("latest calculation\n", reportFile.readText(Charsets.UTF_8))
            assertEquals(false, File(reportFile.parentFile, ".${reportFile.name}.backup").exists())
        } finally {
            reportFile.delete()
        }
    }
}
