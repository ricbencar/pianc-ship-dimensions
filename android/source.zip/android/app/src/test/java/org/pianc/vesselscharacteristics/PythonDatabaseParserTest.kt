package org.pianc.vesselscharacteristics

import org.pianc.vesselscharacteristics.data.DataValue
import org.pianc.vesselscharacteristics.data.PiancDatabase
import org.pianc.vesselscharacteristics.data.PythonDatabaseParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PythonDatabaseParserTest {
    @Test
    fun bundledDatabasesRemainSeparateAndByteForByteEquivalentToTheReferenceFiles() {
        val wg121 = readMainAsset(PiancDatabase.WG121.assetName)
        val wg235 = readMainAsset(PiancDatabase.WG235.assetName)

        assertEquals(
            "9419f848d0b200ea958fe2e13d0dc6973b2890a797d94aa2ffb9cc996a9f1514",
            sha256(wg121),
        )
        assertEquals(
            "970fbbc9e8648fefd23276732a0e38fa0e71316b8dcd43f255bf4b8e3dff6640",
            sha256(wg235),
        )
        assertTrue(wg121.startsWith("wg121_data = {"))
        assertTrue(wg235.startsWith("wg235_data = {"))
    }

    @Test
    fun wg235ParsesEveryVesselAndPreservesCategoricalAndMissingValues() {
        val dataset = PythonDatabaseParser(readMainAsset(PiancDatabase.WG235.assetName))
            .parse(PiancDatabase.WG235)

        assertEquals(14, dataset.vessels.size)
        assertEquals(164, dataset.vessels.sumOf { it.rowCount })
        assertEquals(
            listOf(
                "Crude Oil & Larger Product Tankers",
                "Product Chemical and Dual Product Tankers (small/medium)",
                "Bulk Carriers",
                "LNG Carriers",
                "LPG Carriers",
                "Container Ships (Post-Panamax)",
                "Container Ships (Panamax & smaller)",
                "General Cargo Vessels",
                "Refrigerated Cargo",
                "Freight RoRo Ships",
                "Car Carriers",
                "Ferries",
                "Cruise Liners",
                "Fishing Vessels > 200 GT",
            ),
            dataset.vessels.map { it.name },
        )
        assertTrue(dataset.vessels.all { it.columns.size == 19 })

        val postPanamax = requireNotNull(dataset.vessel("Container Ships (Post-Panamax)"))
        assertEquals(16, postPanamax.rowCount)
        assertEquals(
            DataValue.Text("Post-Panamax"),
            postPanamax.column("Class_name")?.values?.first(),
        )
        assertEquals(
            DataValue.Missing,
            postPanamax.column("Air_draft_ballast (m)")?.values?.last(),
        )
        assertFalse(postPanamax.column("Class_name")!!.isNumeric)
        assertTrue(postPanamax.column("DWT_deadweight_tonnage (t)")!!.isNumeric)
    }

    @Test
    fun wg121ParsesEveryVesselAndMatchesPythonInputColumnFiltering() {
        val dataset = PythonDatabaseParser(readMainAsset(PiancDatabase.WG121.assetName))
            .parse(PiancDatabase.WG121)

        assertEquals(23, dataset.vessels.size)
        assertEquals(200, dataset.vessels.sumOf { it.rowCount })
        assertTrue(dataset.vessels.all { it.columns.size == 10 })

        val motorBoats = requireNotNull(dataset.vessel("Motor Boats"))
        assertEquals(6, motorBoats.rowCount)
        assertEquals(
            listOf(
                "Loa_Length_overall (m)",
                "B_beam (m)",
                "T_laden (m)",
                "dm_fully_laden (t)",
            ),
            motorBoats.inputColumns().map { it.name },
        )
        assertTrue(
            motorBoats.column("Lbp_length_between_perpendiculars (m)")
                ?.values
                ?.all { it == DataValue.Missing } == true,
        )
    }
}
