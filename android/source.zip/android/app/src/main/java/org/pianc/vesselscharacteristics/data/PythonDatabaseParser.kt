package org.pianc.vesselscharacteristics.data

/**
 * Parser for the deliberately small Python-literal subset used by the two bundled
 * PIANC source files: nested dictionaries, lists, strings, numbers and `np.nan`.
 * The source files stay byte-for-byte separate assets rather than being folded into
 * generated Kotlin code.
 */
class PythonDatabaseParser(private val source: String) {
    private var position = 0

    fun parse(database: PiancDatabase): VesselDataset {
        skipWhitespace()
        parseIdentifier()
        skipWhitespace()
        expect('=')
        val root = parseDictionary()
        skipWhitespace()
        check(position == source.length) {
            "Unexpected content at character $position."
        }

        val vessels = root.values.entries.map { (vesselName, vesselNode) ->
            val columnMap = vesselNode as? Node.Dictionary
                ?: parseFailure("Expected a dictionary for vessel type '$vesselName'.")
            val columns = columnMap.values.entries.map { (columnName, columnNode) ->
                val list = columnNode as? Node.ListValue
                    ?: parseFailure("Expected a list for '$vesselName / $columnName'.")
                VesselColumn(
                    name = columnName,
                    values = list.values.map { node ->
                        when (node) {
                            is Node.NumberValue -> DataValue.Numeric(node.value)
                            is Node.StringValue -> DataValue.Text(node.value)
                            Node.Missing -> DataValue.Missing
                            else -> parseFailure(
                                "Unsupported value in '$vesselName / $columnName'.",
                            )
                        }
                    },
                )
            }
            VesselTable(name = vesselName, columns = columns)
        }
        return VesselDataset(database = database, vessels = vessels)
    }

    private fun parseValue(): Node {
        skipWhitespace()
        if (position >= source.length) parseFailure("Unexpected end of file.")
        return when (source[position]) {
            '{' -> parseDictionary()
            '[' -> parseList()
            '\'', '"' -> Node.StringValue(parseString())
            '+', '-', '.', in '0'..'9' -> Node.NumberValue(parseNumber())
            else -> {
                val identifier = parseIdentifier()
                if (identifier == "np.nan" || identifier == "nan") {
                    Node.Missing
                } else {
                    parseFailure("Unsupported identifier '$identifier'.")
                }
            }
        }
    }

    private fun parseDictionary(): Node.Dictionary {
        expect('{')
        val values = linkedMapOf<String, Node>()
        skipWhitespace()
        while (!consumeIf('}')) {
            val key = parseString()
            skipWhitespace()
            expect(':')
            val value = parseValue()
            check(values.put(key, value) == null) { "Duplicate key '$key'." }
            skipWhitespace()
            if (consumeIf('}')) break
            expect(',')
            skipWhitespace()
            if (consumeIf('}')) break
        }
        return Node.Dictionary(values)
    }

    private fun parseList(): Node.ListValue {
        expect('[')
        val values = mutableListOf<Node>()
        skipWhitespace()
        while (!consumeIf(']')) {
            values += parseValue()
            skipWhitespace()
            if (consumeIf(']')) break
            expect(',')
            skipWhitespace()
            if (consumeIf(']')) break
        }
        return Node.ListValue(values)
    }

    private fun parseString(): String {
        skipWhitespace()
        if (position >= source.length || (source[position] != '\'' && source[position] != '"')) {
            parseFailure("Expected a quoted string.")
        }
        val quote = source[position++]
        return buildString {
            while (position < source.length) {
                val character = source[position++]
                when {
                    character == quote -> return@buildString
                    character == '\\' -> {
                        if (position >= source.length) parseFailure("Unfinished escape sequence.")
                        append(
                            when (val escaped = source[position++]) {
                                'n' -> '\n'
                                'r' -> '\r'
                                't' -> '\t'
                                '\\' -> '\\'
                                '\'' -> '\''
                                '"' -> '"'
                                else -> escaped
                            },
                        )
                    }
                    else -> append(character)
                }
            }
            parseFailure("Unterminated string.")
        }
    }

    private fun parseNumber(): Double {
        skipWhitespace()
        val start = position
        if (peek() == '+' || peek() == '-') position++
        while (peek()?.isDigit() == true) position++
        if (peek() == '.') {
            position++
            while (peek()?.isDigit() == true) position++
        }
        if (peek() == 'e' || peek() == 'E') {
            position++
            if (peek() == '+' || peek() == '-') position++
            val exponentStart = position
            while (peek()?.isDigit() == true) position++
            if (exponentStart == position) parseFailure("Invalid numeric exponent.")
        }
        return source.substring(start, position).toDoubleOrNull()
            ?: parseFailure("Invalid number at character $start.")
    }

    private fun parseIdentifier(): String {
        skipWhitespace()
        val start = position
        while (peek()?.let { it.isLetterOrDigit() || it == '_' || it == '.' } == true) {
            position++
        }
        if (start == position) parseFailure("Expected an identifier.")
        return source.substring(start, position)
    }

    private fun expect(expected: Char) {
        skipWhitespace()
        if (position >= source.length || source[position] != expected) {
            parseFailure("Expected '$expected'.")
        }
        position++
    }

    private fun consumeIf(expected: Char): Boolean {
        skipWhitespace()
        if (position < source.length && source[position] == expected) {
            position++
            return true
        }
        return false
    }

    private fun skipWhitespace() {
        while (position < source.length && source[position].isWhitespace()) position++
    }

    private fun peek(): Char? = source.getOrNull(position)

    private fun parseFailure(message: String): Nothing = error("$message Position: $position")

    private sealed interface Node {
        data class Dictionary(val values: LinkedHashMap<String, Node>) : Node
        data class ListValue(val values: List<Node>) : Node
        data class StringValue(val value: String) : Node
        data class NumberValue(val value: Double) : Node
        data object Missing : Node
    }
}
