package org.pianc.vesselscharacteristics.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import org.pianc.vesselscharacteristics.R
import org.pianc.vesselscharacteristics.ui.theme.FormulaTextStyle
import org.pianc.vesselscharacteristics.ui.theme.HarborGold
import org.pianc.vesselscharacteristics.ui.theme.HarborNavy
import org.pianc.vesselscharacteristics.ui.theme.HarborTeal

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntroductionScreen(onBack: () -> Unit) {
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("introduction_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.introduction_title),
                        fontWeight = FontWeight.Bold,
                    )
                },
                navigationIcon = {
                    TextButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("introduction_back"),
                    ) {
                        Text(stringResource(R.string.back_to_calculator))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            IntroductionHero()

            IntroductionSection(
                number = "01",
                title = "Purpose and scope",
            ) {
                BodyText(
                    "PIANC Vessels Characteristics estimates the remaining properties of a " +
                        "design vessel from one known numeric characteristic. Select a PIANC " +
                        "database, a vessel type, an input characteristic, and a value. The app " +
                        "then evaluates every compatible characteristic in that vessel table and " +
                        "returns the results in the source column order.",
                )
                BodyText(
                    "The calculator is intended for preliminary port, harbour, waterway, berth, " +
                        "and marine-infrastructure studies. It reproduces the desktop calculator's " +
                        "selection rules, interpolation method, range checks, categorical lookup, " +
                        "rounding, and report structure while operating entirely on the device.",
                )
            }

            IntroductionSection(
                number = "02",
                title = "Embedded PIANC databases",
            ) {
                DatabaseSourceCard(
                    title = "PIANC MarCom WG235 · 2022",
                    badge = "Current fleet",
                    description = "Ship Dimensions and Data for Design of Marine Infrastructure. " +
                        "This is the more recent and comprehensive source and is the default choice " +
                        "for contemporary design-vessel studies.",
                )
                DatabaseSourceCard(
                    title = "PIANC MarCom WG121 · 2014",
                    badge = "Reference fleet",
                    description = "Harbour Approach Channels – Design Guidelines. This earlier " +
                        "dataset remains useful for vessel classes covered by the 2014 guidance, " +
                        "historical comparison, and projects whose criteria cite WG121.",
                )
                BodyText(
                    "The two source files are bundled separately as wg235_database.txt and " +
                        "wg121_database.txt. Switching the database changes the available vessel " +
                        "types, input characteristics, valid ranges, and result columns. Values are " +
                        "never combined across the two publications.",
                )
            }

            IntroductionSection(
                number = "03",
                title = "Calculation sequence",
            ) {
                NumberedStep(
                    number = 1,
                    title = "Choose a database",
                    text = "WG235 and WG121 are treated as independent data sources.",
                )
                NumberedStep(
                    number = 2,
                    title = "Choose a vessel type",
                    text = "The app opens only the table associated with that vessel class.",
                )
                NumberedStep(
                    number = 3,
                    title = "Choose a known characteristic",
                    text = "A column is offered only when it is numeric and contains more than one non-missing value.",
                )
                NumberedStep(
                    number = 4,
                    title = "Enter the known value",
                    text = "The value must lie inside the displayed inclusive range. Extrapolation is not permitted.",
                )
                NumberedStep(
                    number = 5,
                    title = "Estimate the remaining columns",
                    text = "Numeric characteristics use shape-preserving interpolation; text characteristics use the nearest source row.",
                )
                NumberedStep(
                    number = 6,
                    title = "Present and record the result",
                    text = "The ordered result can be copied or shared. Each successful calculation replaces the previously saved private on-device report.",
                )
            }

            IntroductionSection(
                number = "04",
                title = "Numeric method: PCHIP",
            ) {
                BodyText(
                    "Numeric characteristics are evaluated with a Piecewise Cubic Hermite " +
                        "Interpolating Polynomial (PCHIP). PCHIP constructs a cubic polynomial on " +
                        "each interval between adjacent source values while choosing first " +
                        "derivatives that preserve the local shape of the data.",
                )
                FormulaPanel(
                    formula = "pₖ(x) = yₖ + dₖ·s + c₂·s² + c₃·s³, s = x − xₖ",
                    explanation = "For x between xₖ and xₖ₊₁, the value comes from the interval's " +
                        "cubic Hermite polynomial. End values and the selected slopes determine " +
                        "the coefficients.",
                )
                BodyText(
                    "Where neighbouring secant slopes change sign or either slope is zero, the " +
                        "interior derivative is set to zero. Otherwise it is calculated from a " +
                        "weighted harmonic mean of the neighbouring slopes. Endpoint derivatives " +
                        "use a one-sided estimate and are limited so they cannot introduce a new " +
                        "turning point or an excessive overshoot.",
                )
                BodyText(
                    "These rules make PCHIP well suited to vessel tables: monotonic trends such as " +
                        "increasing length or beam are retained between tabulated points, and the " +
                        "oscillations associated with an unconstrained cubic spline are avoided. " +
                        "PCHIP still follows the source data; it does not impose a naval-architecture " +
                        "relationship that is absent from the selected table.",
                )
            }

            IntroductionSection(
                number = "05",
                title = "Data preparation and edge cases",
            ) {
                BulletPoint(
                    "Rows whose selected input value is missing are removed, and the remaining rows " +
                        "are sorted by that input before calculation.",
                )
                BulletPoint(
                    "If several source rows have the same input value, every numeric characteristic " +
                        "is averaged within that input group. This produces the strictly increasing " +
                        "input sequence required by PCHIP.",
                )
                BulletPoint(
                    "Each output characteristic is evaluated only from groups where that output has " +
                        "a numeric value. With fewer than two usable points, the characteristic is " +
                        "marked as insufficient and omitted from the displayed report.",
                )
                BulletPoint(
                    "The selected input characteristic is returned exactly as entered after numeric " +
                        "parsing; it is not recalculated.",
                )
                BulletPoint(
                    "A value equal to the minimum or maximum is valid. A value below the minimum, " +
                        "above the maximum, NaN, or infinite is rejected. The app never extrapolates " +
                        "beyond the selected input column's range.",
                )
                BulletPoint(
                    "A sparse output column may cover less of the input range than the selected input " +
                        "column. If the requested value lies beyond that output's usable support, its " +
                        "numeric result is reported as nan, matching the reference workflow.",
                )
            }

            IntroductionSection(
                number = "06",
                title = "Text values and nearest-row lookup",
            ) {
                BodyText(
                    "Textual fields cannot be interpolated. For these columns, the app finds the " +
                        "original source row whose selected numeric input is closest to the entered " +
                        "value, then returns the text from that row. The lookup uses the sorted source " +
                        "rows before duplicate numeric rows are averaged. A missing text cell is " +
                        "reported as “No data available.”",
                )
                FormulaPanel(
                    formula = "row* = arg minᵢ |xᵢ − xinput|",
                    explanation = "The categorical result is taken from row*. It is a nearest-neighbour " +
                        "classification, not a continuous estimate.",
                )
            }

            IntroductionSection(
                number = "07",
                title = "Rounding and report output",
            ) {
                BodyText(
                    "Most numeric outputs are rounded to two decimal places using ties-to-even " +
                        "rounding. The source column named Capacity, the exact lowercase database " +
                        "columns cargo_capacity_(teu) and cargo_capacity_(cars), and column names " +
                        "containing lowercase passengers are rounded to whole numbers. Other column " +
                        "names retain the ordinary two-decimal rule, including similarly worded names " +
                        "whose capitalization differs.",
                )
                BodyText(
                    "Results retain the database's original column order. Copy and Share export the " +
                        "same plain-text report shown by the reference calculator. A successful report " +
                        "replaces pianc-ship-dimensions.txt in the app's private storage, so only the " +
                        "most recent successful calculation remains saved.",
                )
            }

            IntroductionSection(
                number = "08",
                title = "Reading common characteristics",
            ) {
                DefinitionRow("DWT", "Deadweight tonnage: cargo, fuel, water, stores, crew, and passengers, in tonnes.")
                DefinitionRow("GT", "Gross tonnage: a dimensionless measure derived from enclosed internal volume.")
                DefinitionRow("Loa", "Length overall, measured between the vessel's foremost and aftermost points, in metres.")
                DefinitionRow("lbp", "Length between perpendiculars along the summer load line, in metres.")
                DefinitionRow("B", "Beam: the vessel's maximum width, in metres.")
                DefinitionRow("T", "Draught from waterline to keel, generally the maximum summer draught, in metres.")
                DefinitionRow("Cb", "Block coefficient: submerged hull volume divided by Loa × B × T; dimensionless.")
                DefinitionRow("Displacement", "Total vessel weight, equal to the weight of displaced water, in tonnes.")
                DefinitionRow("Windage area", "Projected lateral or longitudinal area above the waterline, in square metres.")
                BodyText(
                    "Database column names and units are preserved so the result can be traced back " +
                        "to its PIANC table. Check the applicable report whenever a field name, loading " +
                        "condition, capacity basis, or unit needs project-level confirmation.",
                )
            }

            IntroductionSection(
                number = "09",
                title = "Applicability and limitations",
                testTag = "introduction_limitations",
            ) {
                BulletPoint(
                    "An interpolated result is an estimate within a published vessel class. It is not " +
                        "a surveyed particular vessel, a regulatory limit, or a manufacturer guarantee.",
                )
                BulletPoint(
                    "Relationships are one-dimensional: every output is inferred from the single known " +
                        "characteristic. The method does not jointly fit several known vessel properties.",
                )
                BulletPoint(
                    "PCHIP preserves the shape of each table but cannot correct source uncertainty, " +
                        "mixed fleets, sparse samples, or changes in vessel design after publication.",
                )
                BulletPoint(
                    "Nearest-row text values can change abruptly at the midpoint between source rows " +
                        "and should be treated as descriptive categories rather than interpolated facts.",
                )
                BulletPoint(
                    "Choose the database required by the governing design guidance. For final design, " +
                        "verify dimensions against project criteria, current fleet information, owner " +
                        "or operator data, class records, and the cited PIANC publication.",
                )
            }

            IntroductionSection(
                number = "10",
                title = "References and offline operation",
            ) {
                ReferenceText(
                    "PIANC MarCom Working Group 235 (2022), Ship Dimensions and Data for Design of Marine Infrastructure.",
                )
                ReferenceText(
                    "PIANC MarCom Working Group 121 (2014), Harbour Approach Channels – Design Guidelines.",
                )
                BodyText(
                    "Both database files ship inside the application package and are read locally. " +
                        "The calculator needs no network connection and does not upload vessel inputs " +
                        "or results. Database names on the calculator identify the exact embedded " +
                        "source used for each result.",
                )
            }

            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.return_to_calculator),
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun IntroductionHero() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.linearGradient(listOf(HarborNavy, HarborTeal)),
                shape = RoundedCornerShape(24.dp),
            )
            .padding(24.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = stringResource(R.string.brand_title),
                color = HarborGold,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
            )
            Text(
                text = stringResource(R.string.introduction_subtitle),
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Text(
                text = stringResource(R.string.introduction_lead),
                color = Color.White.copy(alpha = 0.88f),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun IntroductionSection(
    number: String,
    title: String,
    testTag: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (testTag == null) Modifier else Modifier.testTag(testTag)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = number,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            content()
        }
    }
}

@Composable
private fun BodyText(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.bodyLarge,
    )
}

@Composable
private fun DatabaseSourceCard(title: String, badge: String, description: String) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = badge.uppercase(),
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Black,
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = description,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun NumberedStep(number: Int, title: String, text: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Surface(
            shape = RoundedCornerShape(9.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
        ) {
            Text(
                text = number.toString(),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                fontWeight = FontWeight.Bold,
            )
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(
                text = text,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun FormulaPanel(formula: String, explanation: String) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = formula,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.primary,
                style = FormulaTextStyle,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = explanation,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun BulletPoint(text: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            text = "•",
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Black,
        )
        Text(
            text = text,
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge,
        )
    }
}

@Composable
private fun DefinitionRow(term: String, definition: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
            text = term,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = definition,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun ReferenceText(text: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(14.dp),
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}
