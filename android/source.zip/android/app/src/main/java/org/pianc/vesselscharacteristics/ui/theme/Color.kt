package org.pianc.vesselscharacteristics.ui.theme

import androidx.compose.ui.graphics.Color

val HarborNavy = Color(0xFF062F44)
val HarborBlue = Color(0xFF0B6484)
val HarborTeal = Color(0xFF078A8F)
val HarborGold = Color(0xFFFFD84D)
val HarborBackground = Color(0xFFF3F7F8)
val HarborSurface = Color(0xFFFFFFFF)
val HarborText = Color(0xFF142C36)
val HarborMutedText = Color(0xFF536B75)
val HarborOutline = Color(0xFF71858D)
val HarborOutlineVariant = Color(0xFFC8D6DA)
val HarborPrimaryContainer = Color(0xFFD2ECF6)
val HarborSecondaryContainer = Color(0xFFD3F1EE)
val HarborSurfaceVariant = Color(0xFFE2ECEF)

val HarborDarkBackground = Color(0xFF07191F)
val HarborDarkSurface = Color(0xFF0C252E)
val HarborDarkSurfaceVariant = Color(0xFF183840)
val HarborDarkPrimary = Color(0xFF8BD1EC)
val HarborDarkSecondary = Color(0xFF78D8D5)
val HarborDarkText = Color(0xFFEAF4F6)
val HarborDarkMutedText = Color(0xFFB6C9CF)
val HarborDarkOutline = Color(0xFF879AA1)
val HarborDarkOutlineVariant = Color(0xFF334E56)
val HarborError = Color(0xFFBA1A1A)
val HarborDarkError = Color(0xFFFFB4AB)
