package org.pianc.vesselscharacteristics.calculation

import org.pianc.vesselscharacteristics.data.CalculatedValue
import org.pianc.vesselscharacteristics.data.CharacteristicResult
import org.pianc.vesselscharacteristics.data.DataValue
import org.pianc.vesselscharacteristics.data.InputOutOfRangeException
import org.pianc.vesselscharacteristics.data.InsufficientInputDataException
import org.pianc.vesselscharacteristics.data.NotEnoughUniquePointsException
import org.pianc.vesselscharacteristics.data.PiancDatabase
import org.pianc.vesselscharacteristics.data.UnknownCharacteristicException
import org.pianc.vesselscharacteristics.data.VesselCalculation
import org.pianc.vesselscharacteristics.data.VesselTable
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs
import kotlin.math.round

object VesselInterpolator {
    private val integerColumns = setOf(
        "Capacity",
        "cargo_capacity_(teu)",
        "cargo_capacity_(cars)",
    )

    fun calculate(
        database: PiancDatabase,
        table: VesselTable,
        knownCharacteristic: String,
        knownValue: Double,
    ): VesselCalculation {
        val inputColumn = table.column(knownCharacteristic)
            ?: throw UnknownCharacteristicException(knownCharacteristic)
        if (!inputColumn.isNumeric) throw UnknownCharacteristicException(knownCharacteristic)

        val validValues = inputColumn.validNumericValues
        if (validValues.size < 2) throw InsufficientInputDataException(knownCharacteristic)
        val minimum = validValues.min()
        val maximum = validValues.max()
        if (!knownValue.isFinite() || knownValue < minimum || knownValue > maximum) {
            throw InputOutOfRangeException(
                characteristic = knownCharacteristic,
                suppliedValue = knownValue,
                minimum = minimum,
                maximum = maximum,
            )
        }

        // Equivalent to dropna(subset=[x]).sort_values(by=x), while retaining the
        // original row index for nearest-neighbour categorical lookup.
        val sortedRows = inputColumn.values.mapIndexedNotNull { index, value ->
            (value as? DataValue.Numeric)?.let { IndexedValue(index, it.value) }
        }.sortedBy { it.value }
        val groupedRows = sortedRows.groupByTo(linkedMapOf()) { it.value }
        if (groupedRows.size < 2) throw NotEnoughUniquePointsException(knownCharacteristic)

        val closestOriginalRow = sortedRows.minBy { abs(it.value - knownValue) }.index
        val results = table.columns.map { column ->
            val calculated = when {
                column.name == knownCharacteristic -> CalculatedValue.Decimal(knownValue)
                column.isNumeric -> interpolateNumericColumn(
                    columnName = column.name,
                    columnValues = column.values,
                    groupedRows = groupedRows,
                    knownValue = knownValue,
                )
                else -> when (val nearestValue = column.values[closestOriginalRow]) {
                    is DataValue.Text -> CalculatedValue.Text(nearestValue.value)
                    is DataValue.Numeric -> CalculatedValue.Decimal(nearestValue.value)
                    DataValue.Missing -> CalculatedValue.Text("No data available")
                }
            }
            CharacteristicResult(name = column.name, value = calculated)
        }

        return VesselCalculation(
            database = database,
            vesselType = table.name,
            knownCharacteristic = knownCharacteristic,
            knownValue = knownValue,
            validMinimum = minimum,
            validMaximum = maximum,
            results = results,
        )
    }

    private fun interpolateNumericColumn(
        columnName: String,
        columnValues: List<DataValue>,
        groupedRows: Map<Double, List<IndexedValue<Double>>>,
        knownValue: Double,
    ): CalculatedValue {
        val points = groupedRows.mapNotNull { (x, rows) ->
            val values = rows.mapNotNull { row ->
                (columnValues[row.index] as? DataValue.Numeric)?.value
            }
            if (values.isEmpty()) null else x to values.average()
        }
        if (points.size < 2) return CalculatedValue.InsufficientData

        val value = PchipInterpolator.interpolate(
            x = points.map { it.first }.toDoubleArray(),
            y = points.map { it.second }.toDoubleArray(),
            value = knownValue,
        )
        return if (columnName in integerColumns || "passengers" in columnName) {
            check(value.isFinite()) {
                "Cannot convert a non-finite interpolated value to an integer."
            }
            CalculatedValue.Integer(round(value).toLong())
        } else {
            CalculatedValue.Decimal(pythonRound(value, 2))
        }
    }

    private fun pythonRound(value: Double, decimalPlaces: Int): Double {
        if (!value.isFinite()) return value
        // BigDecimal(Double) retains the exact binary floating-point value, which
        // reproduces Python's familiar round(2.675, 2) == 2.67 behaviour.
        return BigDecimal(value)
            .setScale(decimalPlaces, RoundingMode.HALF_EVEN)
            .toDouble()
    }
}
