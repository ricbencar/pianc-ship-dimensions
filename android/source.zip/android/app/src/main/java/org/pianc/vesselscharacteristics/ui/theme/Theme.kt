package org.pianc.vesselscharacteristics.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = HarborBlue,
    onPrimary = Color.White,
    primaryContainer = HarborPrimaryContainer,
    onPrimaryContainer = HarborNavy,
    secondary = HarborTeal,
    onSecondary = Color.White,
    secondaryContainer = HarborSecondaryContainer,
    onSecondaryContainer = HarborText,
    tertiary = Color(0xFF8A6800),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE786),
    onTertiaryContainer = Color(0xFF2A2000),
    background = HarborBackground,
    onBackground = HarborText,
    surface = HarborSurface,
    onSurface = HarborText,
    surfaceVariant = HarborSurfaceVariant,
    onSurfaceVariant = HarborMutedText,
    outline = HarborOutline,
    outlineVariant = HarborOutlineVariant,
    error = HarborError,
    onError = Color.White,
)

private val DarkColors = darkColorScheme(
    primary = HarborDarkPrimary,
    onPrimary = Color(0xFF003548),
    primaryContainer = Color(0xFF004D66),
    onPrimaryContainer = Color(0xFFC5E9F7),
    secondary = HarborDarkSecondary,
    onSecondary = Color(0xFF003737),
    secondaryContainer = Color(0xFF005052),
    onSecondaryContainer = Color(0xFF9CF1F0),
    tertiary = HarborGold,
    onTertiary = Color(0xFF3B2F00),
    tertiaryContainer = Color(0xFF584600),
    onTertiaryContainer = Color(0xFFFFE179),
    background = HarborDarkBackground,
    onBackground = HarborDarkText,
    surface = HarborDarkSurface,
    onSurface = HarborDarkText,
    surfaceVariant = HarborDarkSurfaceVariant,
    onSurfaceVariant = HarborDarkMutedText,
    outline = HarborDarkOutline,
    outlineVariant = HarborDarkOutlineVariant,
    error = HarborDarkError,
    onError = Color(0xFF690005),
)

@Composable
fun VesselsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = VesselsTypography,
        content = content,
    )
}
