package org.pianc.vesselscharacteristics

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import org.pianc.vesselscharacteristics.ui.IntroductionScreen
import org.pianc.vesselscharacteristics.ui.VesselsScreen
import org.pianc.vesselscharacteristics.ui.VesselsViewModel
import org.pianc.vesselscharacteristics.ui.theme.VesselsTheme

class MainActivity : ComponentActivity() {
    private val viewModel: VesselsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VesselsTheme {
                val state by viewModel.state.collectAsState()
                var showIntroduction by rememberSaveable { mutableStateOf(false) }
                val screenStateHolder = rememberSaveableStateHolder()

                BackHandler(enabled = showIntroduction) {
                    showIntroduction = false
                }

                val screenKey = if (showIntroduction) "introduction" else "calculator"
                screenStateHolder.SaveableStateProvider(screenKey) {
                    if (showIntroduction) {
                        IntroductionScreen(onBack = { showIntroduction = false })
                    } else {
                        VesselsScreen(
                            state = state,
                            onIntent = viewModel::onIntent,
                            onShowIntroduction = { showIntroduction = true },
                        )
                    }
                }
            }
        }
    }
}
