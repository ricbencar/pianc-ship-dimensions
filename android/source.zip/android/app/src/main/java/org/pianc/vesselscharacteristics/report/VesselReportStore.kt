package org.pianc.vesselscharacteristics.report

import java.io.File
import java.io.IOException

object VesselReportStore {
    /** Replaces the saved report only after the new UTF-8 file is completely written. */
    fun replace(destination: File, report: String) {
        val target = destination.absoluteFile
        val directory = target.parentFile
            ?: throw IOException("The report destination has no parent directory.")
        if (!directory.exists() && !directory.mkdirs()) {
            throw IOException("The report directory could not be created.")
        }

        val backup = File(directory, ".${target.name}.backup")
        if (backup.exists()) {
            if (target.exists()) {
                if (!backup.delete()) throw IOException("A stale report backup could not be removed.")
            } else if (!backup.renameTo(target)) {
                throw IOException("The previous report backup could not be restored.")
            }
        }

        val temporary = File.createTempFile(".${target.name}.", ".tmp", directory)
        try {
            temporary.outputStream().bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write(report)
            }

            if (target.exists() && !target.renameTo(backup)) {
                throw IOException("The previous report could not be prepared for replacement.")
            }
            if (!temporary.renameTo(target)) {
                if (backup.exists()) backup.renameTo(target)
                throw IOException("The new report could not replace the previous report.")
            }
            if (backup.exists() && !backup.delete()) backup.deleteOnExit()
        } finally {
            if (temporary.exists()) temporary.delete()
        }
    }
}
