package org.pianc.vesselscharacteristics.calculation

import kotlin.math.abs

/** Shape-preserving cubic interpolation equivalent to SciPy's PchipInterpolator. */
internal object PchipInterpolator {
    fun interpolate(x: DoubleArray, y: DoubleArray, value: Double): Double {
        require(x.size == y.size && x.size >= 2)
        require(x.indices.drop(1).all { x[it] > x[it - 1] })
        if (value < x.first() || value > x.last()) return Double.NaN

        val interval = when (value) {
            x.last() -> x.lastIndex - 1
            else -> x.binarySearch(value).let { found ->
                if (found >= 0) found.coerceAtMost(x.lastIndex - 1) else (-found - 2)
            }
        }
        val derivatives = derivatives(x, y)
        val width = x[interval + 1] - x[interval]
        val normalized = (value - x[interval]) / width
        val normalizedSquared = normalized * normalized
        val normalizedCubed = normalizedSquared * normalized

        return (2.0 * normalizedCubed - 3.0 * normalizedSquared + 1.0) * y[interval] +
            (normalizedCubed - 2.0 * normalizedSquared + normalized) * width * derivatives[interval] +
            (-2.0 * normalizedCubed + 3.0 * normalizedSquared) * y[interval + 1] +
            (normalizedCubed - normalizedSquared) * width * derivatives[interval + 1]
    }

    private fun derivatives(x: DoubleArray, y: DoubleArray): DoubleArray {
        val count = x.size
        val widths = DoubleArray(count - 1) { x[it + 1] - x[it] }
        val slopes = DoubleArray(count - 1) { (y[it + 1] - y[it]) / widths[it] }
        if (count == 2) return doubleArrayOf(slopes[0], slopes[0])

        val result = DoubleArray(count)
        result[0] = endpointDerivative(widths[0], widths[1], slopes[0], slopes[1])
        result[count - 1] = endpointDerivative(
            widths[count - 2],
            widths[count - 3],
            slopes[count - 2],
            slopes[count - 3],
        )

        for (index in 1 until count - 1) {
            val before = slopes[index - 1]
            val after = slopes[index]
            result[index] = if (before == 0.0 || after == 0.0 || before.signBit() != after.signBit()) {
                0.0
            } else {
                val firstWeight = 2.0 * widths[index] + widths[index - 1]
                val secondWeight = widths[index] + 2.0 * widths[index - 1]
                (firstWeight + secondWeight) /
                    (firstWeight / before + secondWeight / after)
            }
        }
        return result
    }

    private fun endpointDerivative(
        firstWidth: Double,
        secondWidth: Double,
        firstSlope: Double,
        secondSlope: Double,
    ): Double {
        var derivative = ((2.0 * firstWidth + secondWidth) * firstSlope -
            firstWidth * secondSlope) / (firstWidth + secondWidth)
        if (derivative.signBit() != firstSlope.signBit()) {
            derivative = 0.0
        } else if (firstSlope.signBit() != secondSlope.signBit() &&
            abs(derivative) > 3.0 * abs(firstSlope)
        ) {
            derivative = 3.0 * firstSlope
        }
        return derivative
    }

    private fun Double.signBit(): Boolean = toRawBits() < 0
}
