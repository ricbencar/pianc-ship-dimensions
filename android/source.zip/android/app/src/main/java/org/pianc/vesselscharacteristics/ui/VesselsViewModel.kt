package org.pianc.vesselscharacteristics.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import org.pianc.vesselscharacteristics.calculation.VesselInterpolator
import org.pianc.vesselscharacteristics.data.PiancDatabase
import org.pianc.vesselscharacteristics.data.VesselCalculation
import org.pianc.vesselscharacteristics.data.VesselDatabaseRepository
import org.pianc.vesselscharacteristics.data.VesselDataset
import org.pianc.vesselscharacteristics.report.VesselReportFormatter
import org.pianc.vesselscharacteristics.report.VesselReportStore
import java.io.IOException
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

data class InputRange(
    val minimum: Double,
    val maximum: Double,
)

data class VesselsUiState(
    val databaseOptions: List<PiancDatabase> = PiancDatabase.entries,
    val selectedDatabase: PiancDatabase = PiancDatabase.WG235,
    val vesselTypes: List<String> = emptyList(),
    val selectedVesselType: String = "",
    val characteristics: List<String> = emptyList(),
    val selectedCharacteristic: String = "",
    val knownValue: String = "",
    val inputRange: InputRange? = null,
    val knownValueHasError: Boolean = false,
    val isLoading: Boolean = true,
    val isCalculating: Boolean = false,
    val loadError: String? = null,
    val message: String? = null,
    val calculation: VesselCalculation? = null,
    val report: String = "",
) {
    val canCalculate: Boolean
        get() = !isLoading &&
            !isCalculating &&
            selectedVesselType.isNotEmpty() &&
            selectedCharacteristic.isNotEmpty() &&
            knownValue.isNotBlank()
}

sealed interface VesselsIntent {
    data class DatabaseSelected(val database: PiancDatabase) : VesselsIntent

    data class VesselTypeSelected(val vesselType: String) : VesselsIntent

    data class CharacteristicSelected(val characteristic: String) : VesselsIntent

    data class KnownValueChanged(val value: String) : VesselsIntent

    data object Calculate : VesselsIntent

    data object RetryLoading : VesselsIntent

    data object DismissMessage : VesselsIntent
}

class VesselsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = VesselDatabaseRepository(application.assets)
    private var datasets: Map<PiancDatabase, VesselDataset> = emptyMap()
    private val reportWriteMutex = Mutex()
    private val latestReportVersion = AtomicLong()

    private val mutableState = MutableStateFlow(VesselsUiState())
    val state: StateFlow<VesselsUiState> = mutableState.asStateFlow()

    init {
        loadDatabases()
    }

    fun onIntent(intent: VesselsIntent) {
        when (intent) {
            is VesselsIntent.DatabaseSelected -> selectDatabase(intent.database)
            is VesselsIntent.VesselTypeSelected -> selectVesselType(intent.vesselType)
            is VesselsIntent.CharacteristicSelected -> selectCharacteristic(intent.characteristic)
            is VesselsIntent.KnownValueChanged -> mutableState.update {
                it.copy(
                    knownValue = intent.value,
                    knownValueHasError = false,
                    message = null,
                    calculation = null,
                    report = "",
                )
            }
            VesselsIntent.Calculate -> calculate()
            VesselsIntent.RetryLoading -> loadDatabases()
            VesselsIntent.DismissMessage -> mutableState.update { it.copy(message = null) }
        }
    }

    private fun loadDatabases() {
        mutableState.update {
            it.copy(
                isLoading = true,
                loadError = null,
                message = null,
                calculation = null,
                report = "",
            )
        }
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) { repository.loadAll() }
            }.onSuccess { loaded ->
                datasets = loaded
                val selectedDatabase = mutableState.value.selectedDatabase
                val vesselTypes = loaded[selectedDatabase]?.vessels.orEmpty().map { it.name }
                mutableState.update {
                    it.copy(
                        isLoading = false,
                        vesselTypes = vesselTypes,
                        selectedVesselType = "",
                        characteristics = emptyList(),
                        selectedCharacteristic = "",
                        knownValue = "",
                        inputRange = null,
                    )
                }
            }.onFailure { error ->
                datasets = emptyMap()
                mutableState.update {
                    it.copy(
                        isLoading = false,
                        loadError = error.message ?: "The embedded databases could not be loaded.",
                    )
                }
            }
        }
    }

    private fun selectDatabase(database: PiancDatabase) {
        val vesselTypes = datasets[database]?.vessels.orEmpty().map { it.name }
        mutableState.update {
            it.copy(
                selectedDatabase = database,
                vesselTypes = vesselTypes,
                selectedVesselType = "",
                characteristics = emptyList(),
                selectedCharacteristic = "",
                knownValue = "",
                inputRange = null,
                knownValueHasError = false,
                message = null,
                calculation = null,
                report = "",
            )
        }
    }

    private fun selectVesselType(vesselType: String) {
        val table = datasets[mutableState.value.selectedDatabase]?.vessel(vesselType)
        val characteristics = table?.inputColumns().orEmpty().map { it.name }
        mutableState.update {
            it.copy(
                selectedVesselType = vesselType,
                characteristics = characteristics,
                selectedCharacteristic = "",
                knownValue = "",
                inputRange = null,
                knownValueHasError = false,
                message = null,
                calculation = null,
                report = "",
            )
        }
    }

    private fun selectCharacteristic(characteristic: String) {
        val current = mutableState.value
        val values = datasets[current.selectedDatabase]
            ?.vessel(current.selectedVesselType)
            ?.column(characteristic)
            ?.validNumericValues
            .orEmpty()
        val range = if (values.isEmpty()) null else InputRange(values.min(), values.max())
        mutableState.update {
            it.copy(
                selectedCharacteristic = characteristic,
                knownValue = "",
                inputRange = range,
                knownValueHasError = false,
                message = null,
                calculation = null,
                report = "",
            )
        }
    }

    private fun calculate() {
        val current = mutableState.value
        val parsedValue = current.knownValue.trim().toDoubleOrNull()
        if (parsedValue == null) {
            mutableState.update {
                it.copy(
                    knownValueHasError = true,
                    message = "Enter a valid numeric value.",
                    calculation = null,
                    report = "",
                )
            }
            return
        }

        val table = datasets[current.selectedDatabase]?.vessel(current.selectedVesselType)
        if (table == null || current.selectedCharacteristic.isEmpty()) {
            mutableState.update {
                it.copy(
                    message = "Select a vessel type and known characteristic before calculating.",
                    calculation = null,
                    report = "",
                )
            }
            return
        }

        mutableState.update { it.copy(isCalculating = true, message = null) }
        runCatching {
            VesselInterpolator.calculate(
                database = current.selectedDatabase,
                table = table,
                knownCharacteristic = current.selectedCharacteristic,
                knownValue = parsedValue,
            )
        }.onSuccess { calculation ->
            val report = VesselReportFormatter.format(calculation)
            mutableState.update {
                it.copy(
                    isCalculating = false,
                    knownValueHasError = false,
                    calculation = calculation,
                    report = report,
                )
            }
            replaceSavedReport(report, latestReportVersion.incrementAndGet())
        }.onFailure { error ->
            mutableState.update {
                it.copy(
                    isCalculating = false,
                    knownValueHasError = true,
                    message = error.message ?: "The calculation could not be completed.",
                    calculation = null,
                    report = "",
                )
            }
        }
    }

    private fun replaceSavedReport(report: String, version: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                reportWriteMutex.withLock {
                    // A superseded write must never replace the newest calculation.
                    if (version != latestReportVersion.get()) return@withLock
                    val reportFile = getApplication<Application>()
                        .getFileStreamPath(REPORT_FILE_NAME)
                    VesselReportStore.replace(reportFile, report)
                }
            }.onFailure { error ->
                if (version != latestReportVersion.get()) return@onFailure
                val reason = if (error is IOException) error.message else null
                mutableState.update {
                    it.copy(
                        message = buildString {
                            append("The result was calculated, but its report could not be saved.")
                            if (!reason.isNullOrBlank()) append(" $reason")
                        },
                    )
                }
            }
        }
    }

    private companion object {
        const val REPORT_FILE_NAME = "pianc-ship-dimensions.txt"
    }
}
