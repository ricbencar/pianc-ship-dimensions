package org.pianc.vesselscharacteristics.report

import org.pianc.vesselscharacteristics.data.CalculatedValue
import org.pianc.vesselscharacteristics.data.VesselCalculation

object VesselReportFormatter {
    fun format(calculation: VesselCalculation): String = buildString {
        // The desktop reference starts every generated report with a blank line.
        appendLine()
        appendLine(
            "--- '${calculation.vesselType}' with ${calculation.knownCharacteristic} = " +
                "${calculation.knownValue} (based on ${calculation.database.displayName} database) ---",
        )
        calculation.results.forEach { result ->
            if (result.value != CalculatedValue.InsufficientData) {
                append("  - ")
                append(result.name.padEnd(45))
                append(": ")
                appendLine(result.value.asReportText())
            }
        }
        appendLine("----------------------------------------------------------------------------------------------------------------")
    }

    fun CalculatedValue.asReportText(): String = when (this) {
        is CalculatedValue.Decimal -> if (value.isNaN()) "nan" else value.toString()
        is CalculatedValue.Integer -> value.toString()
        is CalculatedValue.Text -> value
        CalculatedValue.InsufficientData -> "N/A (Insufficient data)"
    }
}
