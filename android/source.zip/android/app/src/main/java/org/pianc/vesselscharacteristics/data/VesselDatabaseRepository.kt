package org.pianc.vesselscharacteristics.data

import android.content.res.AssetManager

class VesselDatabaseRepository(private val assetManager: AssetManager) {
    fun load(database: PiancDatabase): VesselDataset {
        val source = assetManager.open(database.assetName).bufferedReader(Charsets.UTF_8).use {
            it.readText()
        }
        return PythonDatabaseParser(source).parse(database)
    }

    fun loadAll(): Map<PiancDatabase, VesselDataset> = PiancDatabase.entries.associateWith(::load)
}
