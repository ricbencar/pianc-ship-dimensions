package org.pianc.vesselscharacteristics.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.pianc.vesselscharacteristics.R
import org.pianc.vesselscharacteristics.data.CalculatedValue
import org.pianc.vesselscharacteristics.data.PiancDatabase
import org.pianc.vesselscharacteristics.data.VesselCalculation
import org.pianc.vesselscharacteristics.report.VesselReportFormatter
import org.pianc.vesselscharacteristics.ui.theme.HarborGold
import org.pianc.vesselscharacteristics.ui.theme.HarborNavy
import org.pianc.vesselscharacteristics.ui.theme.HarborTeal
import java.util.Locale
import kotlinx.coroutines.launch

@Composable
fun VesselsScreen(
    state: VesselsUiState,
    onIntent: (VesselsIntent) -> Unit,
    onShowIntroduction: () -> Unit,
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()
    val copiedMessage = stringResource(R.string.report_copied)

    state.message?.let { message ->
        AlertDialog(
            onDismissRequest = { onIntent(VesselsIntent.DismissMessage) },
            title = { Text(stringResource(R.string.attention_title)) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { onIntent(VesselsIntent.DismissMessage) }) {
                    Text(stringResource(R.string.dismiss))
                }
            },
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
        ) {
            BrandHeader()

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                IntroductionSeparator(onClick = onShowIntroduction)

                if (state.loadError != null) {
                    DatabaseLoadError(
                        message = state.loadError,
                        onRetry = { onIntent(VesselsIntent.RetryLoading) },
                    )
                } else {
                    InputCard(state = state, onIntent = onIntent)
                }

                state.calculation?.let { calculation ->
                    ResultsCard(
                        calculation = calculation,
                        onCopy = {
                            val clipboard = context.getSystemService(ClipboardManager::class.java)
                            clipboard?.setPrimaryClip(
                                ClipData.newPlainText("PIANC vessel characteristics", state.report),
                            )
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar(copiedMessage)
                            }
                        },
                        onShare = { shareReport(context, state.report) },
                    )
                }
                if (state.calculation == null && !state.isLoading) {
                    EmptyResultsCard()
                }

                MethodNote()
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun BrandHeader() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.linearGradient(
                    colors = listOf(HarborNavy, Color(0xFF075A78), HarborTeal),
                ),
            )
            .padding(horizontal = 20.dp, vertical = 28.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Surface(
                modifier = Modifier.size(62.dp),
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.28f),
                ),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "VC",
                        color = HarborGold,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                    )
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = stringResource(R.string.brand_title),
                    color = HarborGold,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                )
                Text(
                    text = stringResource(R.string.brand_subtitle),
                    color = Color.White.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun IntroductionSeparator(onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        HorizontalDivider(modifier = Modifier.weight(1f))
        TextButton(
            onClick = onClick,
            modifier = Modifier.testTag("introduction_link"),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        ) {
            Text(
                text = stringResource(R.string.introduction_link),
                fontWeight = FontWeight.SemiBold,
            )
        }
        HorizontalDivider(modifier = Modifier.weight(1f))
    }
}

@Composable
private fun DatabaseLoadError(message: String, onRetry: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
        ),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(R.string.database_load_error_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(message, style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onRetry) {
                Text(stringResource(R.string.retry))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun InputCard(
    state: VesselsUiState,
    onIntent: (VesselsIntent) -> Unit,
) {
    val focusManager = LocalFocusManager.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = stringResource(R.string.inputs_title),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = stringResource(R.string.inputs_hint),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }

            Text(
                text = stringResource(R.string.database_label),
                style = MaterialTheme.typography.labelLarge,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                state.databaseOptions.forEach { database ->
                    FilterChip(
                        selected = state.selectedDatabase == database,
                        onClick = { onIntent(VesselsIntent.DatabaseSelected(database)) },
                        label = {
                            Text(
                                text = database.shortLabel(),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("database_${database.name.lowercase(Locale.US)}"),
                        enabled = !state.isLoading,
                    )
                }
            }
            Text(
                text = state.selectedDatabase.displayName,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
            )

            SelectionField(
                label = stringResource(R.string.vessel_type_label),
                value = state.selectedVesselType,
                placeholder = stringResource(R.string.vessel_type_placeholder),
                options = state.vesselTypes,
                enabled = !state.isLoading && state.vesselTypes.isNotEmpty(),
                testTag = "vessel_type_field",
                onSelected = { onIntent(VesselsIntent.VesselTypeSelected(it)) },
            )

            SelectionField(
                label = stringResource(R.string.characteristic_label),
                value = state.selectedCharacteristic,
                placeholder = stringResource(R.string.characteristic_placeholder),
                options = state.characteristics,
                enabled = state.selectedVesselType.isNotEmpty() && state.characteristics.isNotEmpty(),
                testTag = "characteristic_field",
                onSelected = { onIntent(VesselsIntent.CharacteristicSelected(it)) },
            )

            OutlinedTextField(
                value = state.knownValue,
                onValueChange = { onIntent(VesselsIntent.KnownValueChanged(it)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("known_value_field"),
                enabled = state.selectedCharacteristic.isNotEmpty(),
                label = { Text(stringResource(R.string.value_label)) },
                placeholder = { Text(stringResource(R.string.value_placeholder)) },
                supportingText = {
                    when {
                        state.knownValueHasError -> Text(stringResource(R.string.invalid_value))
                        state.inputRange != null -> Text(
                            stringResource(
                                R.string.valid_range,
                                formatCompact(state.inputRange.minimum),
                                formatCompact(state.inputRange.maximum),
                            ),
                        )
                    }
                },
                isError = state.knownValueHasError,
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Decimal,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        focusManager.clearFocus()
                        if (state.canCalculate) onIntent(VesselsIntent.Calculate)
                    },
                ),
            )

            Button(
                onClick = {
                    focusManager.clearFocus()
                    onIntent(VesselsIntent.Calculate)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("calculate_button"),
                enabled = state.canCalculate,
                shape = RoundedCornerShape(14.dp),
            ) {
                if (state.isLoading || state.isCalculating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                } else {
                    Text(
                        text = stringResource(R.string.calculate),
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SelectionField(
    label: String,
    value: String,
    placeholder: String,
    options: List<String>,
    enabled: Boolean,
    testTag: String,
    onSelected: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(enabled) {
        if (!enabled) expanded = false
    }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { if (enabled) expanded = it },
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable, enabled)
                .testTag(testTag),
            enabled = enabled,
            readOnly = true,
            singleLine = true,
            label = { Text(label) },
            placeholder = { Text(placeholder) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        onSelected(option)
                        expanded = false
                    },
                )
            }
        }
    }
}

@Composable
private fun EmptyResultsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = stringResource(R.string.results_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = stringResource(R.string.results_empty),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun ResultsCard(
    calculation: VesselCalculation,
    onCopy: () -> Unit,
    onShare: () -> Unit,
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("results_container"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = stringResource(R.string.results_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = calculation.vesselType,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text = stringResource(
                    R.string.result_basis,
                    calculation.knownCharacteristic,
                    formatCompact(calculation.knownValue),
                    calculation.database.displayName,
                ),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
            )

            HorizontalDivider()

            val displayedResults = calculation.results
                .filterNot { it.value == CalculatedValue.InsufficientData }
            displayedResults.forEachIndexed { index, result ->
                ResultRow(
                    label = result.name,
                    value = result.value.displayText(),
                    highlighted = result.name == calculation.knownCharacteristic,
                )
                if (index < displayedResults.lastIndex) {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f),
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(onClick = onCopy, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.copy_action))
                }
                Button(onClick = onShare, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.share_action))
                }
            }
            Text(
                text = stringResource(R.string.saved_report_note),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String, highlighted: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (highlighted) {
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                } else {
                    Modifier.padding(vertical = 6.dp)
                },
            ),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(0.9f),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            text = value,
            modifier = Modifier.weight(1.1f),
            color = MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End,
        )
    }
}

@Composable
private fun MethodNote() {
    Text(
        text = stringResource(R.string.method_note),
        modifier = Modifier.padding(horizontal = 4.dp),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        style = MaterialTheme.typography.bodySmall,
    )
}

private fun PiancDatabase.shortLabel(): String = when (this) {
    PiancDatabase.WG235 -> "WG235 · 2022"
    PiancDatabase.WG121 -> "WG121 · 2014"
}

private fun CalculatedValue.displayText(): String = with(VesselReportFormatter) {
    this@displayText.asReportText()
}

private fun formatCompact(value: Double): String = when {
    value.isNaN() -> "nan"
    value.isInfinite() -> value.toString()
    value == value.toLong().toDouble() -> value.toLong().toString()
    else -> String.format(Locale.US, "%.6f", value).trimEnd('0').trimEnd('.')
}

private fun shareReport(context: Context, report: String) {
    val sendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.share_subject))
        putExtra(Intent.EXTRA_TEXT, report)
    }
    context.startActivity(
        Intent.createChooser(sendIntent, context.getString(R.string.share_chooser_title)),
    )
}
