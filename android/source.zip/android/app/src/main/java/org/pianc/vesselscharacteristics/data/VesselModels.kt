package org.pianc.vesselscharacteristics.data

enum class PiancDatabase(
    val displayName: String,
    val assetName: String,
) {
    WG235(
        displayName = "PIANC WG235 (2022)",
        assetName = "wg235_database.txt",
    ),
    WG121(
        displayName = "PIANC WG121 (2014)",
        assetName = "wg121_database.txt",
    ),
}

sealed interface DataValue {
    data class Numeric(val value: Double) : DataValue

    data class Text(val value: String) : DataValue

    data object Missing : DataValue
}

data class VesselColumn(
    val name: String,
    val values: List<DataValue>,
) {
    /** Matches pandas' numeric-dtype decision for the database files. */
    val isNumeric: Boolean = values.none { it is DataValue.Text }

    val validNumericValues: List<Double>
        get() = values.mapNotNull { (it as? DataValue.Numeric)?.value }
}

data class VesselTable(
    val name: String,
    val columns: List<VesselColumn>,
) {
    val rowCount: Int = columns.firstOrNull()?.values?.size ?: 0

    init {
        require(columns.map { it.name }.distinct().size == columns.size) {
            "Vessel table '$name' contains duplicate column names."
        }
        require(columns.all { it.values.size == rowCount }) {
            "All columns in vessel table '$name' must have the same row count."
        }
    }

    fun column(name: String): VesselColumn? = columns.firstOrNull { it.name == name }

    fun inputColumns(): List<VesselColumn> = columns.filter {
        it.isNumeric && it.validNumericValues.size > 1
    }
}

data class VesselDataset(
    val database: PiancDatabase,
    val vessels: List<VesselTable>,
) {
    init {
        require(vessels.map { it.name }.distinct().size == vessels.size) {
            "Database '${database.displayName}' contains duplicate vessel types."
        }
    }

    fun vessel(name: String): VesselTable? = vessels.firstOrNull { it.name == name }
}

sealed interface CalculatedValue {
    data class Decimal(val value: Double) : CalculatedValue

    data class Integer(val value: Long) : CalculatedValue

    data class Text(val value: String) : CalculatedValue

    data object InsufficientData : CalculatedValue
}

data class CharacteristicResult(
    val name: String,
    val value: CalculatedValue,
)

data class VesselCalculation(
    val database: PiancDatabase,
    val vesselType: String,
    val knownCharacteristic: String,
    val knownValue: Double,
    val validMinimum: Double,
    val validMaximum: Double,
    val results: List<CharacteristicResult>,
)

sealed class VesselCalculationException(message: String) : IllegalArgumentException(message)

class UnknownCharacteristicException(name: String) : VesselCalculationException(
    "Unknown characteristic '$name'.",
)

class InsufficientInputDataException(name: String) : VesselCalculationException(
    "Not enough valid data for '$name' in this vessel type to perform interpolation.",
)

class NotEnoughUniquePointsException(name: String) : VesselCalculationException(
    "Not enough unique data points for '$name'.",
)

class InputOutOfRangeException(
    val characteristic: String,
    val suppliedValue: Double,
    val minimum: Double,
    val maximum: Double,
) : VesselCalculationException(
    "The provided value for '$characteristic' ($suppliedValue) is outside the valid data " +
        "range of [$minimum, $maximum].",
)
