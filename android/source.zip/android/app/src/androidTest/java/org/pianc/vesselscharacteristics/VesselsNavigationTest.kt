package org.pianc.vesselscharacteristics

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.v2.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class VesselsNavigationTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun introductionLinkOpensSeparateDetailedScreenAndReturns() {
        composeRule.onNodeWithTag("introduction_link")
            .assertIsDisplayed()
            .performClick()

        composeRule.onNodeWithTag("introduction_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("introduction_back")
            .assertIsDisplayed()
            .performClick()

        composeRule.onNodeWithTag("introduction_link").assertIsDisplayed()
    }

    @Test
    fun installedPackageUsesVesselsIdentity() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("org.pianc.vesselscharacteristics", context.packageName)
    }
}
